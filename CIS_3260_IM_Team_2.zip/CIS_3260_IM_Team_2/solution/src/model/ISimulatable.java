package model;

public interface ISimulatable {
	abstract void iterateSimulation(long time_ms);
}
