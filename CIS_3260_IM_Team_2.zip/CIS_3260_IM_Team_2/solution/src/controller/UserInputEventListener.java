package controller;

public interface UserInputEventListener {
	public abstract void handleUserInput(InputEvent e);
}
